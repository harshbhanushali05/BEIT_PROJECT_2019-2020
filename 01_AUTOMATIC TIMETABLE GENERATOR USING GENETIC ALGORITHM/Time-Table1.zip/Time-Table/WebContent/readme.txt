Demo App for JSP with DHTMLX JavaPlanner 

To purchase Commercial/Enterprise Licence visit http://javaplanner.com/license.html

(c) Dinamenta, UAB