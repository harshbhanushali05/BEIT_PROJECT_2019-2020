package demoapp;

import com.dhtmlx.planner.DHXEventRec;

public class EventRec extends DHXEventRec {

}
